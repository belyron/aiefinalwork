import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
from scipy.stats import ttest_ind
import json
import os

def load_data(path="AirQuality.csv"):
    try:
        df = pd.read_csv(path, sep=";")
        df.columns = [col.strip().replace('\xa0','') for col in df.columns]

        df["Time"] = df["Time"].str.replace(".", ":", regex=False)
        df["Datetime"] = pd.to_datetime(
            df["Date"].astype(str) + " " + df["Time"].astype(str),
            dayfirst=True,
            errors="coerce"
        )
        df = df.dropna(subset=["Datetime"])

        empty_cols = df.columns[df.isna().all()]
        if len(empty_cols) > 0:
            df.drop(columns=empty_cols, inplace=True)

        num_cols = df.select_dtypes(include=['object']).columns[2:]
        for col in num_cols:
            df[col] = (
                df[col].astype(str).str.replace(",", ".").replace("", np.nan)
            )
            df[col] = pd.to_numeric(df[col], errors="coerce")
            df[col].replace(-200, np.nan, inplace=True)

        for col in df.select_dtypes(include=[np.number]).columns:
            df[col].interpolate(inplace=True)
            df[col].fillna(df[col].mean(), inplace=True)

        df = df.sort_values("Datetime").reset_index(drop=True)

        return df

    except Exception as e:
        print("Ошибка при загрузке или обработке данных:", e)
        return None

def show_statistics(df):
    print("\nОписательная статистика")
    print(df.describe())


def check_missing(df):
    print("\nПропуски")
    print(df.isna().sum())


def show_dtypes(df):
    print("\nТипы признаков")
    print(df.dtypes)


def plot_correlations(df):
    numeric_df = df.select_dtypes(include=['float64', 'int64'])
    if numeric_df.empty:
        print("Нет столбцов для корреляции.")
        return
    plt.figure(figsize=(12,6))
    sns.heatmap(numeric_df.corr(), cmap="coolwarm")
    plt.title("Корреляционная матрица")
    plt.show()


def plot_box(df, column):
    if column not in df.columns:
        print("Нет столбца")
        return
    plt.figure(figsize=(7,3))
    sns.boxplot(x=df[column].dropna())
    plt.title(f"Boxplot — {column}")
    plt.show()


def plot_trend(df, column):
    if column not in df.columns:
        print("Нет столбца")
        return
    ts = df.sort_values("Datetime")
    plt.figure(figsize=(10,4))
    plt.plot(ts["Datetime"], ts[column])
    plt.title(f"Тренд — {column}")
    plt.show()

def forecast_linear(df, column):
    if column not in df.columns:
        print("Нет столбца")
        return
    ts = df[["Datetime", column]].dropna().sort_values("Datetime").reset_index(drop=True)
    ts["t"] = np.arange(len(ts))
    model = LinearRegression()
    model.fit(ts[["t"]], ts[column])
    ts["forecast"] = model.predict(ts[["t"]])
    plt.figure(figsize=(10,4))
    plt.plot(ts["Datetime"], ts[column], label="Real")
    plt.plot(ts["Datetime"], ts["forecast"], label="Forecast")
    plt.legend()
    plt.title(f"Линейный прогноз {column}")
    plt.show()

def ttest_example(df, column, hour1, hour2):
    try:
        data1 = df[df["Datetime"].dt.hour == hour1][column].dropna()
        data2 = df[df["Datetime"].dt.hour == hour2][column].dropna()
        t, p = ttest_ind(data1, data2)
        print(f"\nT-test между {hour1} и {hour2} по {column}")
        print("t-значение:", t)
        print("p-значение:", p)
    except Exception as e:
        print("Ошибка:", e)

def filter_by_month(df, month):
    return df[df["Datetime"].dt.month == month]


def filter_by_hour(df, hour):
    return df[df["Datetime"].dt.hour == hour]

def save_results(df, filename="results.json"):
    try:
        data = df.head(20).to_dict()
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        print("Файл сохранён:", filename)
    except Exception as e:
        print("Ошибка сохранения:", e)

def menu(df):
    while True:
        print("\nМЕНЮ")
        print("1 — Описательная статистика")
        print("2 — Пропуски")
        print("3 — Типы данных")
        print("4 — Корреляции")
        print("5 — Boxplot")
        print("6 — Trend график")
        print("7 — Прогноз")
        print("8 — T-test")
        print("9 — Сохранить JSON")
        print("10 — Выход")

        choice = input("Выбор: ")
        if choice == "1":
            show_statistics(df)
        elif choice == "2":
            check_missing(df)
        elif choice == "3":
            show_dtypes(df)
        elif choice == "4":
            plot_correlations(df)
        elif choice == "5":
            col = input("Введите название колонки: ").strip()
            plot_box(df, col)
        elif choice == "6":
            col = input("Введите название колонки: ").strip()
            plot_trend(df, col)
        elif choice == "7":
            col = input("Введите название колонки: ").strip()
            forecast_linear(df, col)
        elif choice == "8":
            col = input("Введите название колонки: ").strip()
            h1 = int(input("Час 1: "))
            h2 = int(input("Час 2: "))
            ttest_example(df, col, h1, h2)
        elif choice == "9":
            save_results(df)
        elif choice == "10":
            print("Выход")
            break
        else:
            print("Неверный ввод")

if __name__ == "__main__":
    path = "AirQuality.csv"
    df = load_data(path)
    if df is not None:
        menu(df)
    else:
        print("Не удалось загрузить")
